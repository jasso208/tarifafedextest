
URL_API_FEDEX = "https://wsbeta.fedex.com:443/xml"